package microservicio1.microservicio_1.service;

import microservicio1.microservicio_1.model.Inventario;

public interface InventarioService {
    Inventario crearInventario(Inventario inventario);


}
public void eliminarInventario(Long id) {
    inventarioRepository.deleteById(id);
}
